package CalculusAssistant;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Controller {

    @FXML
    TextArea resultDisplay;

    @FXML
    TextArea speechDisplay;

    @FXML
    Button speechButton;

    ScriptRunner scriptRunner = new ScriptRunner();

    @FXML
    public void handleSpeechButton(ActionEvent event){
        try {
            scriptRunner.runCommands();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        String speechText = "";
        String resultText = "";

//        try {
//            Scanner inSpeech = new Scanner(new FileReader("/home/okinadikku/Documents/speechText.txt"));
//            Scanner inResult = new Scanner(new FileReader("/home/okinadikku/Documents/resultText.txt"));
//            StringBuilder speechSB = new StringBuilder();
//            StringBuilder resultSB = new StringBuilder();
//            while(inSpeech.hasNext()) {
//                speechSB.append(inSpeech.next());
//            }
//            inSpeech.close();
//
//            while(inResult.hasNext()) {
//                resultSB.append(inResult.next());
//            }
//            inResult.close();
//
//            speechText += speechSB.toString();
//            resultText += resultSB.toString();
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }

        try {
            BufferedReader speechReader = new BufferedReader(new FileReader("/home/okinadikku/Documents/speechText.txt"));
            //while(speechReader. != null){
                speechText += speechReader.readLine();
            //}

            BufferedReader resultReader = new BufferedReader(new FileReader("/home/okinadikku/Documents/resultText.txt"));
            //while(resultReader.readLine() != null){
                resultText += resultReader.readLine();
            //}
        } catch (IOException e) {
            e.printStackTrace();
        }

        speechDisplay.setText(speechText);
        resultDisplay.setText(resultText);
    }





}
