from sympy import *
from sympy.parsing.sympy_parser import parse_expr
x = symbols('x', positive=True)
init_printing(use_unicode=True)


def evaluate(command):
	result = parse_expr(command)
	fW = open("/home/okinadikku/Documents/resultText.txt", "w")
	fW.write(str(result))

