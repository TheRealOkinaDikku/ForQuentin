import spacy
import re
from spacy.matcher import Matcher
from spacy.tokens import Span
from spacy.tokenizer import Tokenizer


nlp = spacy.load('en_core_web_sm', disable=['ner'])
matcher = Matcher(nlp.vocab)

commandText = open('/home/okinadikku/Documents/speechText.txt').read()
doc = nlp(commandText)

commandList = []
derCommand = False
intCommand = False
function = False
bounds = []
numbers = []

def event_handler(matcher, doc, i, matches):
	match_id, start, end = matches[i]
	string_match_id = nlp.vocab.strings[match_id]
	der_event(string_match_id)
	int_event(string_match_id)
	bounds_event(string_match_id, doc, start, end)
	cos_event(string_match_id, matches, i, start, len(doc.text))
	sin_event(string_match_id, matches, i, start, len(doc.text))
	tan_event(string_match_id, matches, i, start, len(doc.text))
	naturalLog_event(string_match_id, matches, i, start, len(doc.text))
	var_event(string_match_id, matches, i, doc, start, end)
	onlyNum_event(string_match_id, doc, start, end)
	squared_event(string_match_id)
	

def der_event(match_id):
	if match_id == "Derivative":
		global derCommand
		derCommand = True
		commandList.append("diff(")

def int_event(match_id):
	if match_id == "Integrate":
		global intCommand
		intCommand = True
		commandList.append("integrate(")

def bounds_event(match_id, doc, start, end):
	if match_id == "IntegralBounds":
		lowerBounds = doc[start:start+1].text
		upperBounds = doc[end-1:end].text
		bounds.append(", (x," + lowerBounds + "," + upperBounds + ")")

def cos_event(match_id, matches, i, start, end):
	if match_id == "Cosine":
		global function
		function = True
		if nlp.vocab.strings[matches[i-1][0]] == "Number":
			commandList.append(numbers[0] + "*")
		commandList.append("cos(")
		searchNumVar(start, end)

def sin_event(match_id, matches, i, start, end):
	if match_id == "Sine":
		global function
		function = True
		if nlp.vocab.strings[matches[i-1][0]] == "Number":
			commandList.append(numbers[0] + "*")
		commandList.append("sin(")
		searchNumVar(start, end)

def tan_event(match_id, matches, i, start, end):
	if match_id == "Tangent":
		global function
		function = True
		if nlp.vocab.strings[matches[i-1][0]] == "Number":
			commandList.append(numbers[0] + "*")
		commandList.append("tan(")
		searchNumVar(start, end)

def naturalLog_event(match_id, matches, i, start, end):
	if match_id == "NaturalLog":
		global function
		function = True
		if nlp.vocab.strings[matches[i-1][0]] == "Number":
			commandList.append(numbers[0] + "*")
		commandList.append("ln(")
		searchNumVar(start, end)

def var_event(match_id, matches, i, doc, start, end):
	if match_id == "Variable":
		if nlp.vocab.strings[matches[i-1][0]] == "Number":
			commandList.append("*")
		commandList.append(doc[start:end].text)

def onlyNum_event(match_id, doc, start, end):
	if match_id == "Number":
		numbers.append(doc[start:end].text)

def squared_event(match_id):
	if match_id == "Squared":
		commandList.append("**2")

def searchNumVar(searchStart, searchEnd):
	NUM_PATTERN = re.compile(r"\d+\.?\d*[a-z]{1}")
	for match in re.finditer(NUM_PATTERN, doc.text):
		start, end = match.span()
		print(doc.text[start:end])
		Number = doc.text[start:end-1]
		Variable = doc.text[end-1:end]
		commandList.append(Number + "*" + Variable)
		#print(Number + " " + Variable)


matchDer = [{'LOWER': 'derivative'}]
matchInt = [{'LOWER': 'integrate'}]
matchBounds = [{'LIKE_NUM': True}, {'LOWER': 'to'}, {'LIKE_NUM': True}]
matchCos = [{'LOWER': 'cosine'}]
matchSin = [{'LOWER': 'sine'}]
matchTan = [{'LOWER': 'tangent'}]
matchX = [{'LOWER': 'x'}]
matchSq = [{'LOWER': 'squared'}]
matchNum = [{'LIKE_NUM': True}]
matchNaturalLog = [{'LOWER': 'natural'}, {'LOWER': 'log'}]

matcher.add('Derivative', event_handler, matchDer)
matcher.add('Integrate', event_handler, matchInt)
matcher.add('IntegralBounds', event_handler, matchBounds)
matcher.add('Cosine', event_handler, matchCos)
matcher.add('Sine', event_handler, matchSin)
matcher.add('Tangent', event_handler, matchTan)
matcher.add('Variable', event_handler, matchX)
matcher.add('Squared', event_handler, matchSq)
matcher.add('Number', event_handler, matchNum)
matcher.add('NaturalLog', event_handler, matchNaturalLog)


matches = matcher(doc)

if function == True:
	commandList.append(")")
if derCommand == True:
	commandList.append(", x)")
if intCommand == True:
	commandList.extend(bounds)
	commandList.append(")")

print(commandList)
command = ''.join(commandList)
print(command)

import symPyExample
symPyExample.evaluate(command)
